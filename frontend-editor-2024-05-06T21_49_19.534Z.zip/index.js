let bernardo = (
`girafa`,
`zebra`,
28,
`alfabeto`
{
name: "Luan"
age: 28,
isAdm: true
},
true
)


console.log (`A segunda linha do seu Array é ${bernardo (4). name}`)
